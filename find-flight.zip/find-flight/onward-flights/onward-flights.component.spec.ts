import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OnwardFlightsComponent } from './onward-flights.component';

describe('OnwardFlightsComponent', () => {
  let component: OnwardFlightsComponent;
  let fixture: ComponentFixture<OnwardFlightsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OnwardFlightsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OnwardFlightsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
