import { Component, OnInit, Input } from '@angular/core';
import { ProductCartService } from '../../../services/product-cart/product-cart.service';

@Component({
  selector: 'app-onward-flights',
  templateUrl: './onward-flights.component.html',
  styleUrls: ['./onward-flights.component.scss']
})
export class OnwardFlightsComponent implements OnInit {

  @Input() itineraryDetail;

  constructor(
    private productCart: ProductCartService
  ) { }

  isOnwardFlight = true;

  onAddtoCart() {
    const product = {
      name: 'test',
      work: 'test2'
    }
    this.productCart.addToCart(product);
  }

  ngOnInit() {
  }

}
