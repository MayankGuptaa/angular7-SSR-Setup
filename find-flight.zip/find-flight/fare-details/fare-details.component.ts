import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-fare-details',
  templateUrl: './fare-details.component.html',
  styleUrls: ['./fare-details.component.scss']
})
export class FareDetailsComponent implements OnInit {

  constructor() { }
  @Input() fareDetail;

  ngOnInit() {
    console.log('Fare Detail', this.fareDetail);
  }

}
