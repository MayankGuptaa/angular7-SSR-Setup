import {
  Component,
  OnInit,
  ViewChild,
  Output,
  EventEmitter,
  Input
} from '@angular/core';
import { MatAccordion } from '@angular/material';
import { Options } from 'ng5-slider';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-search-filter',
  templateUrl: './search-filter.component.html',
  styleUrls: ['./search-filter.component.scss']
})
export class SearchFilterComponent implements OnInit {
  constructor(private http: HttpClient) { }
  @Input() isLoading;
  @Output() allFilter = new EventEmitter();

  @ViewChild('myaccordion') myPanels: MatAccordion;
  collapsedH = '45px';
  expandedH = '45px';

  allFilterValues = {
    scaleFilter: {
      type: 'scale-filter',
      values: []
    },
    classFilter: {
      type: 'class-filter',
      values: []
    },
    airlinesFilter: {
      type: 'airlines-filter',
      values: []
    },
    priceFilter: {
      type: 'price-filter',
      values: {
        minPrice: 1000,
        maxPrice: 600000
      }
    }
  };

  scalesCheckList: Array<any> = [
    { title: 'Direct', color: 'warn', value: 0 },
    { title: 'One stop', color: 'warn', value: 1 },
    { title: 'Two or more stops', color: 'warn', value: 2 }
  ];

  airlinesCheckList: Array<any> = [];

  classCheckList: Array<any> = [
    { title: 'Economy', color: 'warn', value: 'E' },
    { title: 'Business', color: 'warn', value: 'B' },
    { title: 'First Class', color: 'warn', value: 'F' }
  ];

  minPrice = 1000;
  maxPrice = 600000;
  priceOptions: Options = {
    floor: 1000,
    ceil: 600000,
    translate: (value: number): string => {
      return '$' + value;
    }
  };

  today = new Date();

  timeTableValue1: number = this.today.getHours();
  timeTableOption1: Options = {
    floor: this.today.getHours(),
    ceil: 24,
    translate: (value: number): string => {
      return `${value} o'clock`;
    }
  };

  timeTableValue2: number = this.today.getHours();
  timeTableOption2: Options = {
    floor: this.today.getHours(),
    ceil: 24,
    translate: (value: number): string => {
      return `${value} o'clock`;
    }
  };


  onScaleFilter(event) {
    const checked = event.checked;
    const val = event.source.value;
    if (checked === true) {
      this.allFilterValues.scaleFilter.values.push(val);
    } else if (checked === false) {
      this.allFilterValues.scaleFilter.values.filter((newVal, i) => {
        if (newVal === val) {
          this.allFilterValues.scaleFilter.values.splice(i, 1);
        }
      });
    }
    this.allFilter.emit(this.allFilterValues);
  }

  onAirlinesFilter(event) {
    const checked = event.checked;
    const val = event.source.value;
    if (checked === true) {
      this.allFilterValues.airlinesFilter.values.push(val);
    } else if (checked === false) {
      this.allFilterValues.airlinesFilter.values.filter((newVal, i) => {
        if (newVal === val) {
          this.allFilterValues.airlinesFilter.values.splice(i, 1);
        }
      });
    }
    this.allFilter.emit(this.allFilterValues);
  }

  onPriceChange(event) {
    this.allFilterValues.priceFilter.values.minPrice = event.value;
    this.allFilterValues.priceFilter.values.maxPrice = event.highValue;
    this.allFilter.emit(this.allFilterValues);
  }

  onClassFilter(event) {
    const checked = event.checked;
    const val = event.source.value;
    if (checked === true) {
      this.allFilterValues.classFilter.values.push(val);
    } else if (checked === false) {
      this.allFilterValues.classFilter.values.filter((newVal, i) => {
        if (newVal === val) {
          this.allFilterValues.classFilter.values.splice(i, 1);
        }
      });
    }
    this.allFilter.emit(this.allFilterValues);
  }

  getPreferredAirline() {
    this.http.get('Airline/GetByText/all').subscribe((res: any) => {
      this.airlinesCheckList = res;
    });
  }

  ngOnInit() {
    this.getPreferredAirline();
    setTimeout(() => {
      this.myPanels.openAll();
    }, 10);
  }
}
