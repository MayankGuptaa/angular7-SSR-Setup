import { Component, OnInit, Input } from '@angular/core';
@Component({
  selector: 'app-one-way',
  templateUrl: './one-way.component.html',
  styleUrls: ['./one-way.component.scss']
})
export class OneWayComponent implements OnInit {

  @Input() itineraryDetail;

  constructor() { }

  onPriceSelect() {
  }

  ngOnInit() {
  }

}
