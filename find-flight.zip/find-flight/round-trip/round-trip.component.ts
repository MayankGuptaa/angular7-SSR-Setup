import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-round-trip',
  templateUrl: './round-trip.component.html',
  styleUrls: ['./round-trip.component.scss']
})
export class RoundTripComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
