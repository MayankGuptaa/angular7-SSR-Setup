import { Component, OnInit , Input} from '@angular/core';

@Component({
  selector: 'app-flight-details',
  templateUrl: './flight-details.component.html',
  styleUrls: ['./flight-details.component.scss']
})
export class FlightDetailsComponent implements OnInit {

  constructor() { }
  @Input() itineraryDetail;
  isAirlineStops = false;

  ngOnInit() {
    console.log(this.itineraryDetail);
  }

}
