import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { FlexLayoutModule } from '@angular/flex-layout';

import { FindFlightComponent } from './find-flight.component';

import { FlightsFormModule } from '../search-filters/flights-form/flights-form.module';
import { SearchFilterComponent } from './search-filter/search-filter.component';

import { MatExpansionModule } from '@angular/material/expansion';
import { Ng5SliderModule } from 'ng5-slider';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatRadioModule} from '@angular/material/radio';
import { FlightPricesDaysComponent } from './flight-prices-days/flight-prices-days.component';
import { PricesByAirlinesComponent } from './prices-by-airlines/prices-by-airlines.component';
import { FlightDetailsComponent } from './flight-details/flight-details.component';
import { FareDetailsComponent } from './fare-details/fare-details.component';
import { OnwardFlightsComponent } from './onward-flights/onward-flights.component';
import { MatProgressSpinnerModule} from '@angular/material/progress-spinner';
import { MatButtonModule} from '@angular/material/button';
import { RoundTripComponent } from './round-trip/round-trip.component';
import { OneWayComponent } from './one-way/one-way.component';
import { TimeFormate } from './timeFormate.pipe';

import { AddImagePathPipeModule } from '../../pipes/add-img-path-pipe/addImagePath.module';

const routes: Routes = [
    { path: '', component: FindFlightComponent },
];

@NgModule({
    declarations: [
        FindFlightComponent,
        SearchFilterComponent,
        FlightPricesDaysComponent,
        PricesByAirlinesComponent,
        FlightDetailsComponent,
        FareDetailsComponent,
        OnwardFlightsComponent,
        RoundTripComponent,
        OneWayComponent,
        TimeFormate
    ],
    imports: [
        CommonModule,
        MatRadioModule,
        RouterModule.forChild(routes),
        FlexLayoutModule,
        FlightsFormModule,
        MatButtonModule,
        MatExpansionModule,
        Ng5SliderModule,
        MatCheckboxModule,
        MatProgressSpinnerModule,
        AddImagePathPipeModule
    ]
})

export class FindFlightModule {}
