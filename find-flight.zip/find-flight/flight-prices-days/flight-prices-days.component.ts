import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-flight-prices-days',
  templateUrl: './flight-prices-days.component.html',
  styleUrls: ['./flight-prices-days.component.scss']
})
export class FlightPricesDaysComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
