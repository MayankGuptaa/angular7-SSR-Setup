import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FlightPricesDaysComponent } from './flight-prices-days.component';

describe('FlightPricesDaysComponent', () => {
  let component: FlightPricesDaysComponent;
  let fixture: ComponentFixture<FlightPricesDaysComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FlightPricesDaysComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FlightPricesDaysComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
