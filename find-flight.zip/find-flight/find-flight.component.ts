import { Component, OnInit, OnDestroy, Directive } from '@angular/core';
import { SetSearchDataService } from '../../services/set-data/set-search-data.service';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { Title, Meta } from '@angular/platform-browser';

@Component({
  selector: 'app-find-flight',
  templateUrl: './find-flight.component.html',
  styleUrls: ['./find-flight.component.scss']
})
export class FindFlightComponent implements OnInit, OnDestroy {

  constructor(
    private router: Router,
    private setSearchData: SetSearchDataService,
    private http: HttpClient,
    private title: Title,
    private meta: Meta
  ) {
    this.title.setTitle('Find Flight Result Title');
    this.meta.updateTag({
      name: 'Find Flight Result Meta'
    });
  }

  flightSearchDataList: Array<any> = [];
  flightSearchDataStore: Array<any> = [];
  filterFlightArray: Array<any> = [];

  totalpage: number = 0;
  currentPage: number = 1;
  itemCounter: number = 8;
  perPage: number = 8;

  isNoDataFound = false;
  isLoading = false;

  isActiveActive = 'isPricesByAirlines';
  priceAirlinesTabs: Array<any> = [
    { title: 'Prices by Airlines', type: 'isPricesByAirlines' },
    { title: 'Price +/- 3 days', type: 'isPriceDays' }
  ];

  onTabChange(tabType) {
    this.isActiveActive = tabType;
  }

  onFlightDetailTab(tabType, i) {
    if (tabType === 'isFlightDetail') {
      this.flightSearchDataList[i].isFlightDetail = !this.flightSearchDataList[i].isFlightDetail;
      this.flightSearchDataList[i].isFairDetail = false;
    } else if (tabType === 'isFairDetail') {
      this.flightSearchDataList[i].isFairDetail = !this.flightSearchDataList[i].isFairDetail;
      this.flightSearchDataList[i].isFlightDetail = false;
    }
  }


  airlinesFilter(event) {
    console.log(event);
  }

  AllFilter(event) {

    this.isLoading = false;
    this.isNoDataFound = false;

    this.currentPage = 1;
    this.itemCounter = 8;
    this.totalpage = Math.ceil(this.filterFlightArray.length / this.perPage);

    this.flightSearchDataList = this.flightSearchDataStore.filter(item => {

      let flag = true;

      // price filter activation check
      if (event.priceFilter.values) {
        flag = flag && this.priceFilter(item, event.priceFilter.values);
      }

      // scale filter
      if (event.scaleFilter.values.length) {
        flag = flag && this.scaleFilter(item, event.scaleFilter.values);
      }

      // Class filter
      if (event.classFilter.values.length) {
        flag = flag && this.classFilter(item, event.classFilter.values);
      }
      return flag;
    })

    if (!this.flightSearchDataList.length) {
      this.isNoDataFound = true;
    } else {
      this.isNoDataFound = false;
    }

  }

  // Scale Filters
  scaleFilter(item, scaleValues) {
    let flag = false;
    item.itineraryDetail.forEach(e => {
      e.segments.filter((v: any) => {
        if (scaleValues.length) {
          const index = scaleValues.indexOf(v.stop);
          if (index >= 0) {
            flag = true;
          }
        }
      });
    });
    return flag;
  }

  // Class Filter
  classFilter(item, classValues) {
    let flag = false;
    item.itineraryDetail.forEach(e => {
      e.segments.filter((v: any) => {
        if (classValues.length) {
          const index = classValues.indexOf(v.classService);
          if (index >= 0) {
            flag = true;
          }
        }
      });
    });
    return flag;
  }

  // Price Filter
  priceFilter(item, filterCondition) {
    let flag = false;
    item.costs.forEach(v => {
      if (v.total > filterCondition.minPrice && v.total < filterCondition.maxPrice) {
        flag = true;
      }
    });
    return flag;
  }

  onLoadMore() {
    if (!this.filterFlightArray.length) {
      if (this.currentPage < this.totalpage - 1) {
        const arrayLength = this.flightSearchDataList.length;
        this.flightSearchDataStore.filter(() => {
          if (this.flightSearchDataList.length < (arrayLength + this.perPage)) {
            this.itemCounter++;
            this.flightSearchDataList.push(this.flightSearchDataStore[this.itemCounter]);
          }
        });
        this.currentPage++;
      } else {
        const arrayLength = this.flightSearchDataStore.length;
        this.flightSearchDataStore.filter(() => {
          if (this.flightSearchDataList.length < arrayLength) {
            this.itemCounter++;
            this.flightSearchDataList.push(this.flightSearchDataStore[this.itemCounter - 1]);
          }
        });
        this.currentPage++;
      }
    } else if (this.filterFlightArray.length) {
      console.log('load 2');
      if (this.currentPage < this.totalpage - 1) {
        const arrayLength = this.flightSearchDataList.length;
        this.filterFlightArray.filter(() => {
          if (this.flightSearchDataList.length < (arrayLength + 8)) {
            this.itemCounter++;
            this.flightSearchDataList.push(this.filterFlightArray[this.itemCounter]);
          }
        });
        this.currentPage++;
      } else {
        const arrayLength = this.filterFlightArray.length;
        this.filterFlightArray.filter(() => {
          if (this.flightSearchDataList.length < arrayLength) {
            this.itemCounter++;
            this.flightSearchDataList.push(this.filterFlightArray[this.itemCounter - 1]);
          }
        });
        this.currentPage++;
      }
    }
    console.log(this.flightSearchDataList);
  }

  ngOnInit() {
    if (!localStorage.getItem(this.setSearchData.findFlightKey)) {
      this.router.navigate([''], { queryParams: { queryParams: 'Please Search Flight' } });
    }
    this.flightSearchDataList.map((val: any) => {
      val.isFlightDetail = false;
      val.isFairDetail = false;
    });


    this.flightSearchDataStore = [
      {
        'totalCost': 0.01,
        'totalCostWithoutFormat': 0.0,
        'itineraryCode': null,
        'totalAdults': 1,
        'totalChildren': 0,
        'totalInfants': 0,
        'totalInfantsSeat': 0,
        'itineraryDetail': [
          {
            'detailCode': 1,
            'segments': [
              {
                'married': null,
                'cockpitCode': 'Y',
                'classService': 'B',
                'departureAirportCode': 'BOG',
                'departureAirportName': 'El Dorado',
                'arrivalAirportCode': 'EOH',
                'arrivalAirportName': 'Enrique Olaya Herrera',
                'airlineCode': '9R',
                'airlineName': 'Servicio Aereo a Territorios Nacion SATENA',
                'operatingAirlineCode': '9R',
                'operatingAirlineName': null,
                'departureDate': '2019-06-23T07:30:00',
                'arrivalDate': '2019-06-23T08:29:00',
                'arrivalTime': '08:29',
                'departureTime': '07:30',
                'flightNumber': 8604,
                'stop': 0,
                'flightTime': 59,
                'airplaneType': null,
                'departureTimeZone': null,
                'arrivalTimeZone': null,
                'class': null,
                'allowanceBaggage': null,
                'chargeBaggage': null,
                'airlineIcon': '/images/airlines/9R.png'
              }
            ],
            'totalScale': 0
          }
        ],
        'costs': [
          {
            'baseRate': 335200.0,
            'equivalentRate': 335200.0,
            'totalTax': 0.0,
            'totalFee': 0.0,
            'totalMerchant': 0.0,
            'totalAdministrativeCharges': 0.0,
            'total': 335200.0,
            'passengerCost': [
              {
                'passengerType': 1,
                'amount': 1,
                'baseRate': 335200.0,
                'taxTotal': 0.0,
                'total': 0.0
              }
            ],
            'totalBase': 335200.0,
            'airportFee': 0.0
          }
        ],
        'promotionPolicies': null,
        'totalIncrement': 0.0,
        'decimals': null,
        'currencyCode': 'COP',
        'provider': 0,
        'typeFind': 4,
        'baggage': null,
        'penalties': null
      },
      {
        'totalCost': 0.02,
        'totalCostWithoutFormat': 0.0,
        'itineraryCode': null,
        'totalAdults': 1,
        'totalChildren': 0,
        'totalInfants': 0,
        'totalInfantsSeat': 0,
        'itineraryDetail': [
          {
            'detailCode': 1,
            'segments': [
              {
                'married': null,
                'cockpitCode': 'S',
                'classService': 'B',
                'departureAirportCode': 'BOG',
                'departureAirportName': 'El Dorado',
                'arrivalAirportCode': 'EOH',
                'arrivalAirportName': 'Enrique Olaya Herrera',
                'airlineCode': '9R',
                'airlineName': 'Servicio Aereo a Territorios Nacion SATENA',
                'operatingAirlineCode': '9R',
                'operatingAirlineName': null,
                'departureDate': '2019-06-23T07:30:00',
                'arrivalDate': '2019-06-23T08:29:00',
                'arrivalTime': '08:29',
                'departureTime': '07:30',
                'flightNumber': 8604,
                'stop': 0,
                'flightTime': 59,
                'airplaneType': null,
                'departureTimeZone': null,
                'arrivalTimeZone': null,
                'class': null,
                'allowanceBaggage': null,
                'chargeBaggage': null,
                'airlineIcon': '/images/airlines/9R.png'
              }
            ],
            'totalScale': 0
          }
        ],
        'costs': [
          {
            'baseRate': 318200.0,
            'equivalentRate': 318200.0,
            'totalTax': 0.0,
            'totalFee': 0.0,
            'totalMerchant': 0.0,
            'totalAdministrativeCharges': 0.0,
            'total': 318200.0,
            'passengerCost': [
              {
                'passengerType': 1,
                'amount': 1,
                'baseRate': 318200.0,
                'taxTotal': 0.0,
                'total': 0.0
              }
            ],
            'totalBase': 318200.0,
            'airportFee': 0.0
          }
        ],
        'promotionPolicies': null,
        'totalIncrement': 0.0,
        'decimals': null,
        'currencyCode': 'COP',
        'provider': 0,
        'typeFind': 4,
        'baggage': null,
        'penalties': null
      },
      {
        'totalCost': 0.03,
        'totalCostWithoutFormat': 0.0,
        'itineraryCode': null,
        'totalAdults': 1,
        'totalChildren': 0,
        'totalInfants': 0,
        'totalInfantsSeat': 0,
        'itineraryDetail': [
          {
            'detailCode': 1,
            'segments': [
              {
                'married': null,
                'cockpitCode': 'E',
                'classService': 'E',
                'departureAirportCode': 'BOG',
                'departureAirportName': 'El Dorado',
                'arrivalAirportCode': 'EOH',
                'arrivalAirportName': 'Enrique Olaya Herrera',
                'airlineCode': '9R',
                'airlineName': 'Servicio Aereo a Territorios Nacion SATENA',
                'operatingAirlineCode': '9R',
                'operatingAirlineName': null,
                'departureDate': '2019-06-23T07:30:00',
                'arrivalDate': '2019-06-23T08:29:00',
                'arrivalTime': '08:29',
                'departureTime': '07:30',
                'flightNumber': 8604,
                'stop': 2,
                'flightTime': 59,
                'airplaneType': null,
                'departureTimeZone': null,
                'arrivalTimeZone': null,
                'class': null,
                'allowanceBaggage': null,
                'chargeBaggage': null,
                'airlineIcon': '/images/airlines/9R.png'
              }
            ],
            'totalScale': 0
          }
        ],
        'costs': [
          {
            'baseRate': 301200.0,
            'equivalentRate': 301200.0,
            'totalTax': 0.0,
            'totalFee': 0.0,
            'totalMerchant': 0.0,
            'totalAdministrativeCharges': 0.0,
            'total': 301200.0,
            'passengerCost': [
              {
                'passengerType': 1,
                'amount': 1,
                'baseRate': 301200.0,
                'taxTotal': 0.0,
                'total': 0.0
              }
            ],
            'totalBase': 301200.0,
            'airportFee': 0.0
          }
        ],
        'promotionPolicies': null,
        'totalIncrement': 0.0,
        'decimals': null,
        'currencyCode': 'COP',
        'provider': 0,
        'typeFind': 4,
        'baggage': null,
        'penalties': null
      },
      {
        'totalCost': 0.04,
        'totalCostWithoutFormat': 0.0,
        'itineraryCode': null,
        'totalAdults': 1,
        'totalChildren': 0,
        'totalInfants': 0,
        'totalInfantsSeat': 0,
        'itineraryDetail': [
          {
            'detailCode': 1,
            'segments': [
              {
                'married': null,
                'cockpitCode': 'W',
                'classService': 'B',
                'departureAirportCode': 'BOG',
                'departureAirportName': 'El Dorado',
                'arrivalAirportCode': 'EOH',
                'arrivalAirportName': 'Enrique Olaya Herrera',
                'airlineCode': '9R',
                'airlineName': 'Servicio Aereo a Territorios Nacion SATENA',
                'operatingAirlineCode': '9R',
                'operatingAirlineName': null,
                'departureDate': '2019-06-23T07:30:00',
                'arrivalDate': '2019-06-23T08:29:00',
                'arrivalTime': '08:29',
                'departureTime': '07:30',
                'flightNumber': 8604,
                'stop': 2,
                'flightTime': 59,
                'airplaneType': null,
                'departureTimeZone': null,
                'arrivalTimeZone': null,
                'class': null,
                'allowanceBaggage': null,
                'chargeBaggage': null,
                'airlineIcon': '/images/airlines/9R.png'
              }
            ],
            'totalScale': 0
          }
        ],
        'costs': [
          {
            'baseRate': 284200.0,
            'equivalentRate': 284200.0,
            'totalTax': 0.0,
            'totalFee': 0.0,
            'totalMerchant': 0.0,
            'totalAdministrativeCharges': 0.0,
            'total': 284200.0,
            'passengerCost': [
              {
                'passengerType': 1,
                'amount': 1,
                'baseRate': 284200.0,
                'taxTotal': 0.0,
                'total': 0.0
              }
            ],
            'totalBase': 284200.0,
            'airportFee': 0.0
          }
        ],
        'promotionPolicies': null,
        'totalIncrement': 0.0,
        'decimals': null,
        'currencyCode': 'COP',
        'provider': 0,
        'typeFind': 4,
        'baggage': null,
        'penalties': null
      },
      {
        'totalCost': 0.05,
        'totalCostWithoutFormat': 0.0,
        'itineraryCode': null,
        'totalAdults': 1,
        'totalChildren': 0,
        'totalInfants': 0,
        'totalInfantsSeat': 0,
        'itineraryDetail': [
          {
            'detailCode': 1,
            'segments': [
              {
                'married': null,
                'cockpitCode': 'B',
                'classService': 'B',
                'departureAirportCode': 'BOG',
                'departureAirportName': 'El Dorado',
                'arrivalAirportCode': 'EOH',
                'arrivalAirportName': 'Enrique Olaya Herrera',
                'airlineCode': '9R',
                'airlineName': 'Servicio Aereo a Territorios Nacion SATENA',
                'operatingAirlineCode': '9R',
                'operatingAirlineName': null,
                'departureDate': '2019-06-23T07:30:00',
                'arrivalDate': '2019-06-23T08:29:00',
                'arrivalTime': '08:29',
                'departureTime': '07:30',
                'flightNumber': 8604,
                'stop': 2,
                'flightTime': 59,
                'airplaneType': null,
                'departureTimeZone': null,
                'arrivalTimeZone': null,
                'class': null,
                'allowanceBaggage': null,
                'chargeBaggage': null,
                'airlineIcon': '/images/airlines/9R.png'
              }
            ],
            'totalScale': 0
          }
        ],
        'costs': [
          {
            'baseRate': 264200.0,
            'equivalentRate': 264200.0,
            'totalTax': 0.0,
            'totalFee': 0.0,
            'totalMerchant': 0.0,
            'totalAdministrativeCharges': 0.0,
            'total': 264200.0,
            'passengerCost': [
              {
                'passengerType': 1,
                'amount': 1,
                'baseRate': 264200.0,
                'taxTotal': 0.0,
                'total': 0.0
              }
            ],
            'totalBase': 264200.0,
            'airportFee': 0.0
          }
        ],
        'promotionPolicies': null,
        'totalIncrement': 0.0,
        'decimals': null,
        'currencyCode': 'COP',
        'provider': 0,
        'typeFind': 4,
        'baggage': null,
        'penalties': null
      },
      {
        'totalCost': 0.06,
        'totalCostWithoutFormat': 0.0,
        'itineraryCode': null,
        'totalAdults': 1,
        'totalChildren': 0,
        'totalInfants': 0,
        'totalInfantsSeat': 0,
        'itineraryDetail': [
          {
            'detailCode': 1,
            'segments': [
              {
                'married': null,
                'cockpitCode': 'F',
                'classService': 'F',
                'departureAirportCode': 'BOG',
                'departureAirportName': 'El Dorado',
                'arrivalAirportCode': 'EOH',
                'arrivalAirportName': 'Enrique Olaya Herrera',
                'airlineCode': '9R',
                'airlineName': 'Servicio Aereo a Territorios Nacion SATENA',
                'operatingAirlineCode': '9R',
                'operatingAirlineName': null,
                'departureDate': '2019-06-23T07:30:00',
                'arrivalDate': '2019-06-23T08:29:00',
                'arrivalTime': '08:29',
                'departureTime': '07:30',
                'flightNumber': 8604,
                'stop': 1,
                'flightTime': 59,
                'airplaneType': null,
                'departureTimeZone': null,
                'arrivalTimeZone': null,
                'class': null,
                'allowanceBaggage': null,
                'chargeBaggage': null,
                'airlineIcon': '/images/airlines/9R.png'
              }
            ],
            'totalScale': 0
          }
        ],
        'costs': [
          {
            'baseRate': 249200.0,
            'equivalentRate': 249200.0,
            'totalTax': 0.0,
            'totalFee': 0.0,
            'totalMerchant': 0.0,
            'totalAdministrativeCharges': 0.0,
            'total': 249200.0,
            'passengerCost': [
              {
                'passengerType': 1,
                'amount': 1,
                'baseRate': 249200.0,
                'taxTotal': 0.0,
                'total': 0.0
              }
            ],
            'totalBase': 249200.0,
            'airportFee': 0.0
          }
        ],
        'promotionPolicies': null,
        'totalIncrement': 0.0,
        'decimals': null,
        'currencyCode': 'COP',
        'provider': 0,
        'typeFind': 4,
        'baggage': null,
        'penalties': null
      },
      {
        'totalCost': 0.07,
        'totalCostWithoutFormat': 0.0,
        'itineraryCode': null,
        'totalAdults': 1,
        'totalChildren': 0,
        'totalInfants': 0,
        'totalInfantsSeat': 0,
        'itineraryDetail': [
          {
            'detailCode': 1,
            'segments': [
              {
                'married': null,
                'cockpitCode': 'H',
                'classService': 'H',
                'departureAirportCode': 'BOG',
                'departureAirportName': 'El Dorado',
                'arrivalAirportCode': 'EOH',
                'arrivalAirportName': 'Enrique Olaya Herrera',
                'airlineCode': '9R',
                'airlineName': 'Servicio Aereo a Territorios Nacion SATENA',
                'operatingAirlineCode': '9R',
                'operatingAirlineName': null,
                'departureDate': '2019-06-23T07:30:00',
                'arrivalDate': '2019-06-23T08:29:00',
                'arrivalTime': '08:29',
                'departureTime': '07:30',
                'flightNumber': 8604,
                'stop': 1,
                'flightTime': 59,
                'airplaneType': null,
                'departureTimeZone': null,
                'arrivalTimeZone': null,
                'class': null,
                'allowanceBaggage': null,
                'chargeBaggage': null,
                'airlineIcon': '/images/airlines/9R.png'
              }
            ],
            'totalScale': 0
          }
        ],
        'costs': [
          {
            'baseRate': 234200.0,
            'equivalentRate': 234200.0,
            'totalTax': 0.0,
            'totalFee': 0.0,
            'totalMerchant': 0.0,
            'totalAdministrativeCharges': 0.0,
            'total': 234200.0,
            'passengerCost': [
              {
                'passengerType': 1,
                'amount': 1,
                'baseRate': 234200.0,
                'taxTotal': 0.0,
                'total': 0.0
              }
            ],
            'totalBase': 234200.0,
            'airportFee': 0.0
          }
        ],
        'promotionPolicies': null,
        'totalIncrement': 0.0,
        'decimals': null,
        'currencyCode': 'COP',
        'provider': 0,
        'typeFind': 4,
        'baggage': null,
        'penalties': null
      },
      {
        'totalCost': 0.08,
        'totalCostWithoutFormat': 0.0,
        'itineraryCode': null,
        'totalAdults': 1,
        'totalChildren': 0,
        'totalInfants': 0,
        'totalInfantsSeat': 0,
        'itineraryDetail': [
          {
            'detailCode': 1,
            'segments': [
              {
                'married': null,
                'cockpitCode': 'I',
                'classService': 'I',
                'departureAirportCode': 'BOG',
                'departureAirportName': 'El Dorado',
                'arrivalAirportCode': 'EOH',
                'arrivalAirportName': 'Enrique Olaya Herrera',
                'airlineCode': '9R',
                'airlineName': 'Servicio Aereo a Territorios Nacion SATENA',
                'operatingAirlineCode': '9R',
                'operatingAirlineName': null,
                'departureDate': '2019-06-23T07:30:00',
                'arrivalDate': '2019-06-23T08:29:00',
                'arrivalTime': '08:29',
                'departureTime': '07:30',
                'flightNumber': 8604,
                'stop': 1,
                'flightTime': 59,
                'airplaneType': null,
                'departureTimeZone': null,
                'arrivalTimeZone': null,
                'class': null,
                'allowanceBaggage': null,
                'chargeBaggage': null,
                'airlineIcon': '/images/airlines/9R.png'
              }
            ],
            'totalScale': 0
          }
        ],
        'costs': [
          {
            'baseRate': 219200.0,
            'equivalentRate': 219200.0,
            'totalTax': 0.0,
            'totalFee': 0.0,
            'totalMerchant': 0.0,
            'totalAdministrativeCharges': 0.0,
            'total': 219200.0,
            'passengerCost': [
              {
                'passengerType': 1,
                'amount': 1,
                'baseRate': 219200.0,
                'taxTotal': 0.0,
                'total': 0.0
              }
            ],
            'totalBase': 219200.0,
            'airportFee': 0.0
          }
        ],
        'promotionPolicies': null,
        'totalIncrement': 0.0,
        'decimals': null,
        'currencyCode': 'COP',
        'provider': 0,
        'typeFind': 4,
        'baggage': null,
        'penalties': null
      },
      {
        'totalCost': 0.09,
        'totalCostWithoutFormat': 0.0,
        'itineraryCode': null,
        'totalAdults': 1,
        'totalChildren': 0,
        'totalInfants': 0,
        'totalInfantsSeat': 0,
        'itineraryDetail': [
          {
            'detailCode': 1,
            'segments': [
              {
                'married': null,
                'cockpitCode': 'K',
                'classService': 'K',
                'departureAirportCode': 'BOG',
                'departureAirportName': 'El Dorado',
                'arrivalAirportCode': 'EOH',
                'arrivalAirportName': 'Enrique Olaya Herrera',
                'airlineCode': '9R',
                'airlineName': 'Servicio Aereo a Territorios Nacion SATENA',
                'operatingAirlineCode': '9R',
                'operatingAirlineName': null,
                'departureDate': '2019-06-23T07:30:00',
                'arrivalDate': '2019-06-23T08:29:00',
                'arrivalTime': '08:29',
                'departureTime': '07:30',
                'flightNumber': 8604,
                'stop': 1,
                'flightTime': 59,
                'airplaneType': null,
                'departureTimeZone': null,
                'arrivalTimeZone': null,
                'class': null,
                'allowanceBaggage': null,
                'chargeBaggage': null,
                'airlineIcon': '/images/airlines/9R.png'
              }
            ],
            'totalScale': 0
          }
        ],
        'costs': [
          {
            'baseRate': 202200.0,
            'equivalentRate': 202200.0,
            'totalTax': 0.0,
            'totalFee': 0.0,
            'totalMerchant': 0.0,
            'totalAdministrativeCharges': 0.0,
            'total': 202200.0,
            'passengerCost': [
              {
                'passengerType': 1,
                'amount': 1,
                'baseRate': 202200.0,
                'taxTotal': 0.0,
                'total': 0.0
              }
            ],
            'totalBase': 202200.0,
            'airportFee': 0.0
          }
        ],
        'promotionPolicies': null,
        'totalIncrement': 0.0,
        'decimals': null,
        'currencyCode': 'COP',
        'provider': 0,
        'typeFind': 4,
        'baggage': null,
        'penalties': null
      },
      {
        'totalCost': 0.10,
        'totalCostWithoutFormat': 0.0,
        'itineraryCode': null,
        'totalAdults': 1,
        'totalChildren': 0,
        'totalInfants': 0,
        'totalInfantsSeat': 0,
        'itineraryDetail': [
          {
            'detailCode': 1,
            'segments': [
              {
                'married': null,
                'cockpitCode': 'L',
                'classService': 'L',
                'departureAirportCode': 'BOG',
                'departureAirportName': 'El Dorado',
                'arrivalAirportCode': 'EOH',
                'arrivalAirportName': 'Enrique Olaya Herrera',
                'airlineCode': '9R',
                'airlineName': 'Servicio Aereo a Territorios Nacion SATENA',
                'operatingAirlineCode': '9R',
                'operatingAirlineName': null,
                'departureDate': '2019-06-23T07:30:00',
                'arrivalDate': '2019-06-23T08:29:00',
                'arrivalTime': '08:29',
                'departureTime': '07:30',
                'flightNumber': 8604,
                'stop': 0,
                'flightTime': 59,
                'airplaneType': null,
                'departureTimeZone': null,
                'arrivalTimeZone': null,
                'class': null,
                'allowanceBaggage': null,
                'chargeBaggage': null,
                'airlineIcon': '/images/airlines/9R.png'
              }
            ],
            'totalScale': 0
          }
        ],
        'costs': [
          {
            'baseRate': 187200.0,
            'equivalentRate': 187200.0,
            'totalTax': 0.0,
            'totalFee': 0.0,
            'totalMerchant': 0.0,
            'totalAdministrativeCharges': 0.0,
            'total': 187200.0,
            'passengerCost': [
              {
                'passengerType': 1,
                'amount': 1,
                'baseRate': 187200.0,
                'taxTotal': 0.0,
                'total': 0.0
              }
            ],
            'totalBase': 187200.0,
            'airportFee': 0.0
          }
        ],
        'promotionPolicies': null,
        'totalIncrement': 0.0,
        'decimals': null,
        'currencyCode': 'COP',
        'provider': 0,
        'typeFind': 4,
        'baggage': null,
        'penalties': null
      },
      {
        'totalCost': 0.11,
        'totalCostWithoutFormat': 0.0,
        'itineraryCode': null,
        'totalAdults': 1,
        'totalChildren': 0,
        'totalInfants': 0,
        'totalInfantsSeat': 0,
        'itineraryDetail': [
          {
            'detailCode': 1,
            'segments': [
              {
                'married': null,
                'cockpitCode': 'P',
                'classService': 'P',
                'departureAirportCode': 'BOG',
                'departureAirportName': 'El Dorado',
                'arrivalAirportCode': 'EOH',
                'arrivalAirportName': 'Enrique Olaya Herrera',
                'airlineCode': '9R',
                'airlineName': 'Servicio Aereo a Territorios Nacion SATENA',
                'operatingAirlineCode': '9R',
                'operatingAirlineName': null,
                'departureDate': '2019-06-23T07:30:00',
                'arrivalDate': '2019-06-23T08:29:00',
                'arrivalTime': '08:29',
                'departureTime': '07:30',
                'flightNumber': 8604,
                'stop': 1,
                'flightTime': 59,
                'airplaneType': null,
                'departureTimeZone': null,
                'arrivalTimeZone': null,
                'class': null,
                'allowanceBaggage': null,
                'chargeBaggage': null,
                'airlineIcon': '/images/airlines/9R.png'
              }
            ],
            'totalScale': 0
          }
        ],
        'costs': [
          {
            'baseRate': 172200.0,
            'equivalentRate': 172200.0,
            'totalTax': 0.0,
            'totalFee': 0.0,
            'totalMerchant': 0.0,
            'totalAdministrativeCharges': 0.0,
            'total': 172200.0,
            'passengerCost': [
              {
                'passengerType': 1,
                'amount': 1,
                'baseRate': 172200.0,
                'taxTotal': 0.0,
                'total': 0.0
              }
            ],
            'totalBase': 172200.0,
            'airportFee': 0.0
          }
        ],
        'promotionPolicies': null,
        'totalIncrement': 0.0,
        'decimals': null,
        'currencyCode': 'COP',
        'provider': 0,
        'typeFind': 4,
        'baggage': null,
        'penalties': null
      },
      {
        'totalCost': 0.12,
        'totalCostWithoutFormat': 0.0,
        'itineraryCode': null,
        'totalAdults': 1,
        'totalChildren': 0,
        'totalInfants': 0,
        'totalInfantsSeat': 0,
        'itineraryDetail': [
          {
            'detailCode': 1,
            'segments': [
              {
                'married': null,
                'cockpitCode': 'M',
                'classService': 'M',
                'departureAirportCode': 'BOG',
                'departureAirportName': 'El Dorado',
                'arrivalAirportCode': 'EOH',
                'arrivalAirportName': 'Enrique Olaya Herrera',
                'airlineCode': '9R',
                'airlineName': 'Servicio Aereo a Territorios Nacion SATENA',
                'operatingAirlineCode': '9R',
                'operatingAirlineName': null,
                'departureDate': '2019-06-23T07:30:00',
                'arrivalDate': '2019-06-23T08:29:00',
                'arrivalTime': '08:29',
                'departureTime': '07:30',
                'flightNumber': 8604,
                'stop': 0,
                'flightTime': 59,
                'airplaneType': null,
                'departureTimeZone': null,
                'arrivalTimeZone': null,
                'class': null,
                'allowanceBaggage': null,
                'chargeBaggage': null,
                'airlineIcon': '/images/airlines/9R.png'
              }
            ],
            'totalScale': 0
          }
        ],
        'costs': [
          {
            'baseRate': 157200.0,
            'equivalentRate': 157200.0,
            'totalTax': 0.0,
            'totalFee': 0.0,
            'totalMerchant': 0.0,
            'totalAdministrativeCharges': 0.0,
            'total': 157200.0,
            'passengerCost': [
              {
                'passengerType': 1,
                'amount': 1,
                'baseRate': 157200.0,
                'taxTotal': 0.0,
                'total': 0.0
              }
            ],
            'totalBase': 157200.0,
            'airportFee': 0.0
          }
        ],
        'promotionPolicies': null,
        'totalIncrement': 0.0,
        'decimals': null,
        'currencyCode': 'COP',
        'provider': 0,
        'typeFind': 4,
        'baggage': null,
        'penalties': null
      },
      {
        'totalCost': 0.13,
        'totalCostWithoutFormat': 0.0,
        'itineraryCode': null,
        'totalAdults': 1,
        'totalChildren': 0,
        'totalInfants': 0,
        'totalInfantsSeat': 0,
        'itineraryDetail': [
          {
            'detailCode': 1,
            'segments': [
              {
                'married': null,
                'cockpitCode': 'N',
                'classService': 'N',
                'departureAirportCode': 'BOG',
                'departureAirportName': 'El Dorado',
                'arrivalAirportCode': 'EOH',
                'arrivalAirportName': 'Enrique Olaya Herrera',
                'airlineCode': '9R',
                'airlineName': 'Servicio Aereo a Territorios Nacion SATENA',
                'operatingAirlineCode': '9R',
                'operatingAirlineName': null,
                'departureDate': '2019-06-23T07:30:00',
                'arrivalDate': '2019-06-23T08:29:00',
                'arrivalTime': '08:29',
                'departureTime': '07:30',
                'flightNumber': 8604,
                'stop': 0,
                'flightTime': 59,
                'airplaneType': null,
                'departureTimeZone': null,
                'arrivalTimeZone': null,
                'class': null,
                'allowanceBaggage': null,
                'chargeBaggage': null,
                'airlineIcon': '/images/airlines/9R.png'
              }
            ],
            'totalScale': 0
          }
        ],
        'costs': [
          {
            'baseRate': 140200.0,
            'equivalentRate': 140200.0,
            'totalTax': 0.0,
            'totalFee': 0.0,
            'totalMerchant': 0.0,
            'totalAdministrativeCharges': 0.0,
            'total': 140200.0,
            'passengerCost': [
              {
                'passengerType': 1,
                'amount': 1,
                'baseRate': 140200.0,
                'taxTotal': 0.0,
                'total': 0.0
              }
            ],
            'totalBase': 140200.0,
            'airportFee': 0.0
          }
        ],
        'promotionPolicies': null,
        'totalIncrement': 0.0,
        'decimals': null,
        'currencyCode': 'COP',
        'provider': 0,
        'typeFind': 4,
        'baggage': null,
        'penalties': null
      },
      {
        'totalCost': 0.14,
        'totalCostWithoutFormat': 0.0,
        'itineraryCode': null,
        'totalAdults': 1,
        'totalChildren': 0,
        'totalInfants': 0,
        'totalInfantsSeat': 0,
        'itineraryDetail': [
          {
            'detailCode': 1,
            'segments': [
              {
                'married': null,
                'cockpitCode': 'Y',
                'classService': 'Y',
                'departureAirportCode': 'BOG',
                'departureAirportName': 'El Dorado',
                'arrivalAirportCode': 'EOH',
                'arrivalAirportName': 'Enrique Olaya Herrera',
                'airlineCode': '9R',
                'airlineName': 'Servicio Aereo a Territorios Nacion SATENA',
                'operatingAirlineCode': '9R',
                'operatingAirlineName': null,
                'departureDate': '2019-06-23T13:56:00',
                'arrivalDate': '2019-06-23T14:54:00',
                'arrivalTime': '14:54',
                'departureTime': '13:56',
                'flightNumber': 8767,
                'stop': 0,
                'flightTime': 58,
                'airplaneType': null,
                'departureTimeZone': null,
                'arrivalTimeZone': null,
                'class': null,
                'allowanceBaggage': null,
                'chargeBaggage': null,
                'airlineIcon': '/images/airlines/9R.png'
              }
            ],
            'totalScale': 0
          }
        ],
        'costs': [
          {
            'baseRate': 335200.0,
            'equivalentRate': 335200.0,
            'totalTax': 0.0,
            'totalFee': 0.0,
            'totalMerchant': 0.0,
            'totalAdministrativeCharges': 0.0,
            'total': 335200.0,
            'passengerCost': [
              {
                'passengerType': 1,
                'amount': 1,
                'baseRate': 335200.0,
                'taxTotal': 0.0,
                'total': 0.0
              }
            ],
            'totalBase': 335200.0,
            'airportFee': 0.0
          }
        ],
        'promotionPolicies': null,
        'totalIncrement': 0.0,
        'decimals': null,
        'currencyCode': 'COP',
        'provider': 0,
        'typeFind': 4,
        'baggage': null,
        'penalties': null
      },
      {
        'totalCost': 0.15,
        'totalCostWithoutFormat': 0.0,
        'itineraryCode': null,
        'totalAdults': 1,
        'totalChildren': 0,
        'totalInfants': 0,
        'totalInfantsSeat': 0,
        'itineraryDetail': [
          {
            'detailCode': 1,
            'segments': [
              {
                'married': null,
                'cockpitCode': 'S',
                'classService': 'S',
                'departureAirportCode': 'BOG',
                'departureAirportName': 'El Dorado',
                'arrivalAirportCode': 'EOH',
                'arrivalAirportName': 'Enrique Olaya Herrera',
                'airlineCode': '9R',
                'airlineName': 'Servicio Aereo a Territorios Nacion SATENA',
                'operatingAirlineCode': '9R',
                'operatingAirlineName': null,
                'departureDate': '2019-06-23T13:56:00',
                'arrivalDate': '2019-06-23T14:54:00',
                'arrivalTime': '14:54',
                'departureTime': '13:56',
                'flightNumber': 8767,
                'stop': 0,
                'flightTime': 58,
                'airplaneType': null,
                'departureTimeZone': null,
                'arrivalTimeZone': null,
                'class': null,
                'allowanceBaggage': null,
                'chargeBaggage': null,
                'airlineIcon': '/images/airlines/9R.png'
              }
            ],
            'totalScale': 0
          }
        ],
        'costs': [
          {
            'baseRate': 318200.0,
            'equivalentRate': 318200.0,
            'totalTax': 0.0,
            'totalFee': 0.0,
            'totalMerchant': 0.0,
            'totalAdministrativeCharges': 0.0,
            'total': 318200.0,
            'passengerCost': [
              {
                'passengerType': 1,
                'amount': 1,
                'baseRate': 318200.0,
                'taxTotal': 0.0,
                'total': 0.0
              }
            ],
            'totalBase': 318200.0,
            'airportFee': 0.0
          }
        ],
        'promotionPolicies': null,
        'totalIncrement': 0.0,
        'decimals': null,
        'currencyCode': 'COP',
        'provider': 0,
        'typeFind': 4,
        'baggage': null,
        'penalties': null
      },
      {
        'totalCost': 0.16,
        'totalCostWithoutFormat': 0.0,
        'itineraryCode': null,
        'totalAdults': 1,
        'totalChildren': 0,
        'totalInfants': 0,
        'totalInfantsSeat': 0,
        'itineraryDetail': [
          {
            'detailCode': 1,
            'segments': [
              {
                'married': null,
                'cockpitCode': 'E',
                'classService': 'E',
                'departureAirportCode': 'BOG',
                'departureAirportName': 'El Dorado',
                'arrivalAirportCode': 'EOH',
                'arrivalAirportName': 'Enrique Olaya Herrera',
                'airlineCode': '9R',
                'airlineName': 'Servicio Aereo a Territorios Nacion SATENA',
                'operatingAirlineCode': '9R',
                'operatingAirlineName': null,
                'departureDate': '2019-06-23T13:56:00',
                'arrivalDate': '2019-06-23T14:54:00',
                'arrivalTime': '14:54',
                'departureTime': '13:56',
                'flightNumber': 8767,
                'stop': 0,
                'flightTime': 58,
                'airplaneType': null,
                'departureTimeZone': null,
                'arrivalTimeZone': null,
                'class': null,
                'allowanceBaggage': null,
                'chargeBaggage': null,
                'airlineIcon': '/images/airlines/9R.png'
              }
            ],
            'totalScale': 0
          }
        ],
        'costs': [
          {
            'baseRate': 301200.0,
            'equivalentRate': 301200.0,
            'totalTax': 0.0,
            'totalFee': 0.0,
            'totalMerchant': 0.0,
            'totalAdministrativeCharges': 0.0,
            'total': 301200.0,
            'passengerCost': [
              {
                'passengerType': 1,
                'amount': 1,
                'baseRate': 301200.0,
                'taxTotal': 0.0,
                'total': 0.0
              }
            ],
            'totalBase': 301200.0,
            'airportFee': 0.0
          }
        ],
        'promotionPolicies': null,
        'totalIncrement': 0.0,
        'decimals': null,
        'currencyCode': 'COP',
        'provider': 0,
        'typeFind': 4,
        'baggage': null,
        'penalties': null
      },
      {
        'totalCost': 0.17,
        'totalCostWithoutFormat': 0.0,
        'itineraryCode': null,
        'totalAdults': 1,
        'totalChildren': 0,
        'totalInfants': 0,
        'totalInfantsSeat': 0,
        'itineraryDetail': [
          {
            'detailCode': 1,
            'segments': [
              {
                'married': null,
                'cockpitCode': 'W',
                'classService': 'W',
                'departureAirportCode': 'BOG',
                'departureAirportName': 'El Dorado',
                'arrivalAirportCode': 'EOH',
                'arrivalAirportName': 'Enrique Olaya Herrera',
                'airlineCode': '9R',
                'airlineName': 'Servicio Aereo a Territorios Nacion SATENA',
                'operatingAirlineCode': '9R',
                'operatingAirlineName': null,
                'departureDate': '2019-06-23T13:56:00',
                'arrivalDate': '2019-06-23T14:54:00',
                'arrivalTime': '14:54',
                'departureTime': '13:56',
                'flightNumber': 8767,
                'stop': 0,
                'flightTime': 58,
                'airplaneType': null,
                'departureTimeZone': null,
                'arrivalTimeZone': null,
                'class': null,
                'allowanceBaggage': null,
                'chargeBaggage': null,
                'airlineIcon': '/images/airlines/9R.png'
              }
            ],
            'totalScale': 0
          }
        ],
        'costs': [
          {
            'baseRate': 284200.0,
            'equivalentRate': 284200.0,
            'totalTax': 0.0,
            'totalFee': 0.0,
            'totalMerchant': 0.0,
            'totalAdministrativeCharges': 0.0,
            'total': 284200.0,
            'passengerCost': [
              {
                'passengerType': 1,
                'amount': 1,
                'baseRate': 284200.0,
                'taxTotal': 0.0,
                'total': 0.0
              }
            ],
            'totalBase': 284200.0,
            'airportFee': 0.0
          }
        ],
        'promotionPolicies': null,
        'totalIncrement': 0.0,
        'decimals': null,
        'currencyCode': 'COP',
        'provider': 0,
        'typeFind': 4,
        'baggage': null,
        'penalties': null
      },
      {
        'totalCost': 0.18,
        'totalCostWithoutFormat': 0.0,
        'itineraryCode': null,
        'totalAdults': 1,
        'totalChildren': 0,
        'totalInfants': 0,
        'totalInfantsSeat': 0,
        'itineraryDetail': [
          {
            'detailCode': 1,
            'segments': [
              {
                'married': null,
                'cockpitCode': 'B',
                'classService': 'B',
                'departureAirportCode': 'BOG',
                'departureAirportName': 'El Dorado',
                'arrivalAirportCode': 'EOH',
                'arrivalAirportName': 'Enrique Olaya Herrera',
                'airlineCode': '9R',
                'airlineName': 'Servicio Aereo a Territorios Nacion SATENA',
                'operatingAirlineCode': '9R',
                'operatingAirlineName': null,
                'departureDate': '2019-06-23T13:56:00',
                'arrivalDate': '2019-06-23T14:54:00',
                'arrivalTime': '14:54',
                'departureTime': '13:56',
                'flightNumber': 8767,
                'stop': 0,
                'flightTime': 58,
                'airplaneType': null,
                'departureTimeZone': null,
                'arrivalTimeZone': null,
                'class': null,
                'allowanceBaggage': null,
                'chargeBaggage': null,
                'airlineIcon': '/images/airlines/9R.png'
              }
            ],
            'totalScale': 0
          }
        ],
        'costs': [
          {
            'baseRate': 264200.0,
            'equivalentRate': 264200.0,
            'totalTax': 0.0,
            'totalFee': 0.0,
            'totalMerchant': 0.0,
            'totalAdministrativeCharges': 0.0,
            'total': 264200.0,
            'passengerCost': [
              {
                'passengerType': 1,
                'amount': 1,
                'baseRate': 264200.0,
                'taxTotal': 0.0,
                'total': 0.0
              }
            ],
            'totalBase': 264200.0,
            'airportFee': 0.0
          }
        ],
        'promotionPolicies': null,
        'totalIncrement': 0.0,
        'decimals': null,
        'currencyCode': 'COP',
        'provider': 0,
        'typeFind': 4,
        'baggage': null,
        'penalties': null
      },
      {
        'totalCost': 0.19,
        'totalCostWithoutFormat': 0.0,
        'itineraryCode': null,
        'totalAdults': 1,
        'totalChildren': 0,
        'totalInfants': 0,
        'totalInfantsSeat': 0,
        'itineraryDetail': [
          {
            'detailCode': 1,
            'segments': [
              {
                'married': null,
                'cockpitCode': 'F',
                'classService': 'F',
                'departureAirportCode': 'BOG',
                'departureAirportName': 'El Dorado',
                'arrivalAirportCode': 'EOH',
                'arrivalAirportName': 'Enrique Olaya Herrera',
                'airlineCode': '9R',
                'airlineName': 'Servicio Aereo a Territorios Nacion SATENA',
                'operatingAirlineCode': '9R',
                'operatingAirlineName': null,
                'departureDate': '2019-06-23T13:56:00',
                'arrivalDate': '2019-06-23T14:54:00',
                'arrivalTime': '14:54',
                'departureTime': '13:56',
                'flightNumber': 8767,
                'stop': 0,
                'flightTime': 58,
                'airplaneType': null,
                'departureTimeZone': null,
                'arrivalTimeZone': null,
                'class': null,
                'allowanceBaggage': null,
                'chargeBaggage': null,
                'airlineIcon': '/images/airlines/9R.png'
              }
            ],
            'totalScale': 0
          }
        ],
        'costs': [
          {
            'baseRate': 249200.0,
            'equivalentRate': 249200.0,
            'totalTax': 0.0,
            'totalFee': 0.0,
            'totalMerchant': 0.0,
            'totalAdministrativeCharges': 0.0,
            'total': 249200.0,
            'passengerCost': [
              {
                'passengerType': 1,
                'amount': 1,
                'baseRate': 249200.0,
                'taxTotal': 0.0,
                'total': 0.0
              }
            ],
            'totalBase': 249200.0,
            'airportFee': 0.0
          }
        ],
        'promotionPolicies': null,
        'totalIncrement': 0.0,
        'decimals': null,
        'currencyCode': 'COP',
        'provider': 0,
        'typeFind': 4,
        'baggage': null,
        'penalties': null
      },
      {
        'totalCost': 0.20,
        'totalCostWithoutFormat': 0.0,
        'itineraryCode': null,
        'totalAdults': 1,
        'totalChildren': 0,
        'totalInfants': 0,
        'totalInfantsSeat': 0,
        'itineraryDetail': [
          {
            'detailCode': 1,
            'segments': [
              {
                'married': null,
                'cockpitCode': 'H',
                'classService': 'H',
                'departureAirportCode': 'BOG',
                'departureAirportName': 'El Dorado',
                'arrivalAirportCode': 'EOH',
                'arrivalAirportName': 'Enrique Olaya Herrera',
                'airlineCode': '9R',
                'airlineName': 'Servicio Aereo a Territorios Nacion SATENA',
                'operatingAirlineCode': '9R',
                'operatingAirlineName': null,
                'departureDate': '2019-06-23T13:56:00',
                'arrivalDate': '2019-06-23T14:54:00',
                'arrivalTime': '14:54',
                'departureTime': '13:56',
                'flightNumber': 8767,
                'stop': 0,
                'flightTime': 58,
                'airplaneType': null,
                'departureTimeZone': null,
                'arrivalTimeZone': null,
                'class': null,
                'allowanceBaggage': null,
                'chargeBaggage': null,
                'airlineIcon': '/images/airlines/9R.png'
              }
            ],
            'totalScale': 0
          }
        ],
        'costs': [
          {
            'baseRate': 234200.0,
            'equivalentRate': 234200.0,
            'totalTax': 0.0,
            'totalFee': 0.0,
            'totalMerchant': 0.0,
            'totalAdministrativeCharges': 0.0,
            'total': 234200.0,
            'passengerCost': [
              {
                'passengerType': 1,
                'amount': 1,
                'baseRate': 234200.0,
                'taxTotal': 0.0,
                'total': 0.0
              }
            ],
            'totalBase': 234200.0,
            'airportFee': 0.0
          }
        ],
        'promotionPolicies': null,
        'totalIncrement': 0.0,
        'decimals': null,
        'currencyCode': 'COP',
        'provider': 0,
        'typeFind': 4,
        'baggage': null,
        'penalties': null
      },
      {
        'totalCost': 0.21,
        'totalCostWithoutFormat': 0.0,
        'itineraryCode': null,
        'totalAdults': 1,
        'totalChildren': 0,
        'totalInfants': 0,
        'totalInfantsSeat': 0,
        'itineraryDetail': [
          {
            'detailCode': 1,
            'segments': [
              {
                'married': null,
                'cockpitCode': 'I',
                'classService': 'I',
                'departureAirportCode': 'BOG',
                'departureAirportName': 'El Dorado',
                'arrivalAirportCode': 'EOH',
                'arrivalAirportName': 'Enrique Olaya Herrera',
                'airlineCode': '9R',
                'airlineName': 'Servicio Aereo a Territorios Nacion SATENA',
                'operatingAirlineCode': '9R',
                'operatingAirlineName': null,
                'departureDate': '2019-06-23T13:56:00',
                'arrivalDate': '2019-06-23T14:54:00',
                'arrivalTime': '14:54',
                'departureTime': '13:56',
                'flightNumber': 8767,
                'stop': 0,
                'flightTime': 58,
                'airplaneType': null,
                'departureTimeZone': null,
                'arrivalTimeZone': null,
                'class': null,
                'allowanceBaggage': null,
                'chargeBaggage': null,
                'airlineIcon': '/images/airlines/9R.png'
              }
            ],
            'totalScale': 0
          }
        ],
        'costs': [
          {
            'baseRate': 219200.0,
            'equivalentRate': 219200.0,
            'totalTax': 0.0,
            'totalFee': 0.0,
            'totalMerchant': 0.0,
            'totalAdministrativeCharges': 0.0,
            'total': 219200.0,
            'passengerCost': [
              {
                'passengerType': 1,
                'amount': 1,
                'baseRate': 219200.0,
                'taxTotal': 0.0,
                'total': 0.0
              }
            ],
            'totalBase': 219200.0,
            'airportFee': 0.0
          }
        ],
        'promotionPolicies': null,
        'totalIncrement': 0.0,
        'decimals': null,
        'currencyCode': 'COP',
        'provider': 0,
        'typeFind': 4,
        'baggage': null,
        'penalties': null
      }
    ];

    this.flightSearchDataStore.filter(values => {
      if (this.flightSearchDataList.length < this.perPage) {
        this.flightSearchDataList.push(values);
      }
    });
    this.totalpage = Math.ceil(this.flightSearchDataStore.length / this.perPage);

    // if (localStorage.getItem(this.setSearchData.findFlightKey)) {
    //   this.setSearchData.getSearchData.subscribe(data => {
    //     if (data !== null && data !== undefined) {
    //       this.isLoading = true;
    //       this.http.post('Flight/Search', data).subscribe((res: any) => {
    //           if (res) {
    //             res.forEach(values => {
    //               if (this.flightSearchDataList.length < 8) {
    //                 this.flightSearchDataList.push(values);
    //               }
    //             });
    //             this.flightSearchDataStore = res;
    //             this.totalpage = Math.ceil(this.flightSearchDataStore.length / 8);
    //             this.isLoading = false;
    //             console.log(this.flightSearchDataList);
    //             console.log('Total pages:', this.totalpage, this.flightSearchDataStore.length, res);
    //           }
    //       });
    //     }
    //   });
    // }

  }

  ngOnDestroy() {
    this.setSearchData.removeSearchData(this.setSearchData.findFlightKey);
  }

}





