import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PricesByAirlinesComponent } from './prices-by-airlines.component';

describe('PricesByAirlinesComponent', () => {
  let component: PricesByAirlinesComponent;
  let fixture: ComponentFixture<PricesByAirlinesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PricesByAirlinesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PricesByAirlinesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
