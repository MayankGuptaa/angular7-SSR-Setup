import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-prices-by-airlines',
  templateUrl: './prices-by-airlines.component.html',
  styleUrls: ['./prices-by-airlines.component.scss']
})
export class PricesByAirlinesComponent implements OnInit {

  constructor() { }

  allAirlines: Array<any> = [];

  arr: Array<any> = [
    { name: 'Avianca 1', icon: '', direcPrice: '2,763,182', oneStopPrice: '2,563,182', twoOrMoreStops: '1,563,182'},
    { name: 'Avianca 2', icon: '', direcPrice: '3,763,182', oneStopPrice: '2,63,182', twoOrMoreStops: '1,563,182'},
    { name: 'Avianca 3', icon: '', direcPrice: '4,763,182', oneStopPrice: '2,53,182', twoOrMoreStops: '1,563,182'},
    { name: 'Avianca 4', icon: '', direcPrice: '5,763,182', oneStopPrice: '5,123,182', twoOrMoreStops: '1,563,182'},
    { name: 'Avianca 5', icon: '', direcPrice: '6,763,182', oneStopPrice: '8,56,182', twoOrMoreStops: '1,563,182'},
    { name: 'Avianca 6', icon: '', direcPrice: '7,763,182', oneStopPrice: '7,563,182', twoOrMoreStops: '1,563,182'},
    { name: 'Avianca 7', icon: '', direcPrice: '8,763,182', oneStopPrice: '6,563,182', twoOrMoreStops: '1,563,182'},
    { name: 'Avianca 8', icon: '', direcPrice: '9,763,182', oneStopPrice: '5,563,182', twoOrMoreStops: '1,563,182'},
  ];

  checkIndexRight =  this.arr.length >= 3 ?  3 : this.arr.length - 1;
  checkIndexLeft = 1;


  onSlideRight(i) {
      this.checkIndexRight = i + 1;
      if (this.arr.length  > 4) {
        this.allAirlines.shift();
        this.allAirlines.push(this.arr[this.checkIndexRight]);
      }
  }

  onSlideLeft(i) {
      this.checkIndexLeft = this.checkIndexRight - 4;
      this.checkIndexRight -= 1;
      if (this.arr.length  > 4) {
        this.allAirlines.pop();
        this.allAirlines.unshift(this.arr[this.checkIndexLeft]);
      }
  }

  ngOnInit() {
    if (this.arr.length) {
      this.arr.filter(val => {
        if (this.allAirlines.length < 4) {
          this.allAirlines.push(val);
        }
      });
    }
  }

}
