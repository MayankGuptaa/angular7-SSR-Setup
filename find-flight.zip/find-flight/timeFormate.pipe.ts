import { Pipe, PipeTransform } from '@angular/core';

@Pipe({name: 'getTimeFormate'})
export class TimeFormate implements PipeTransform {
  transform(value: number) {
    const hours = Math.floor(value / 60);
    const minutes = value % 60;
    return hours + ':' + minutes;
  }
}
